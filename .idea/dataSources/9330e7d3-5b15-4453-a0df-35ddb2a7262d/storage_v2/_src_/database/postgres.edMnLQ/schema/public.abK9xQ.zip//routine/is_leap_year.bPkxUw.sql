create function is_leap_year(year integer) returns boolean
    language plpgsql
as
$$
BEGIN
    RETURN (year % 4 = 0 AND year % 100 <> 0) OR (year % 400 = 0);
END;
$$;

alter function is_leap_year(integer) owner to postgres;

